<h1>Zeta DevOps Engineer Test</h1>
<h2>Attempted Questions</h2>
<h4>Part 1</h4>
<p>Question 1</p>
<h4>Part 2</h4>
<p>Question 5</p>
<p>Question 6</p>